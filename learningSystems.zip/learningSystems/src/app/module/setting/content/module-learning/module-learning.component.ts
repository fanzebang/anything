import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-module-learning',
  templateUrl: './module-learning.component.html',
  styleUrls: ['./module-learning.component.scss']
})
export class ModuleLearningComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
