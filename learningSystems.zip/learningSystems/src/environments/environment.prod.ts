export const environment = {
  production: true,
  requestIp:"http://192.168.0.225:38083"
};
